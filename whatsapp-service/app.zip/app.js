const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

// --- SHARED HOSTING LOGGER ---
const logFile = path.join(__dirname, 'debug.log');
const log = (msg) => {
    const text = `[${new Date().toISOString()}] ${msg}\n`;
    console.log(msg);
    try { fs.appendFileSync(logFile, text); } catch (e) {}
};

log('--- STARTING WWEBJS ON SHARED HOSTING ---');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: '*', methods: ['GET', 'POST'] }
});

app.use(cors());
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

let client = null;
let qrCodeData = null;
let connectionStatus = 'disconnected';
let clientUser = null;
let isInitializing = false;

const updateStatus = (status, data = null) => {
    connectionStatus = status;
    io.emit('status', status);
    if (status === 'qr_ready') {
        qrCodeData = data;
        io.emit('qr', data);
    } else if (status === 'connected') {
        clientUser = data;
        io.emit('ready', data);
    }
};

const initializeClient = async () => {
    if (isInitializing) return;
    isInitializing = true;
    
    log('Step 1: Setting up Client with Legacy Headless...');
    
    client = new Client({
        authStrategy: new LocalAuth({
            clientId: "client-one",
            dataPath: "./.wwebjs_auth"
        }),
        webVersionCache: {
            type: 'remote',
            remotePath: 'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.2412.54.html',
        },
        puppeteer: {
            headless: true, // Legacy headless mode (important for shared hosting)
            handleSIGINT: false,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--single-process',
                '--disable-gpu'
            ],
        }
    });

    client.on('qr', async (qr) => {
        log('Step 2: QR Code Received!');
        const qrData = await qrcode.toDataURL(qr);
        updateStatus('qr_ready', qrData);
    });

    client.on('ready', () => {
        log('Step 3: SUCCESS! Client is Ready');
        updateStatus('connected', client.info.wid.user);
        isInitializing = false;
    });

    client.on('authenticated', () => {
        log('Authenticated');
    });

    client.on('auth_failure', (msg) => {
        log(`Auth Failure: ${msg}`);
        isInitializing = false;
        updateStatus('disconnected');
    });

    client.on('disconnected', (reason) => {
        log(`Disconnected: ${reason}`);
        updateStatus('disconnected');
        isInitializing = false;
    });

    try {
        log('Step 4: Launching Browser...');
        await client.initialize();
    } catch (err) {
        log(`FATAL LAUNCH ERROR: ${err.message}`);
        isInitializing = false;
        updateStatus('disconnected');
    }
};

// Start
initializeClient();

// Routes
app.get('/', (req, res) => {
    res.send('<h1>WhatsApp Service (WWebJS)</h1><p>Status: ' + connectionStatus + '</p>');
});

app.get('/status', (req, res) => {
    res.json({
        connected: connectionStatus === 'connected',
        status: connectionStatus,
        phoneNumber: clientUser,
        qrCode: qrCodeData
    });
});

app.post('/initialize', (req, res) => {
    initializeClient();
    res.json({ message: 'Initializing...' });
});

app.post('/send', upload.single('media'), async (req, res) => {
    if (connectionStatus !== 'connected') return res.status(400).json({ error: 'Not connected' });
    const { to, message } = req.body;
    try {
        let jid = to.replace(/[^0-9]/g, '');
        if (jid.length === 10) jid = '91' + jid;
        jid += '@c.us';
        await client.sendMessage(jid, message || '');
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
    log(`WWebJS Service running on port ${PORT}`);
});

process.on('uncaughtException', (err) => log(`UNCAUGHT: ${err.message}`));
